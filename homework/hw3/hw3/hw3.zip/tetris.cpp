#include <iostream>
#include "tetris.h"


Tetris::Tetris(int w){
    width = w;
    heights = new int[w];
    for(int i=0; i < w; ++i ){
        heights[i] = 0;
    }
    data = new char*[w]; // single dimensional array of chars
    for(int i=0; i<w; i++)
    {
        data[i] = new char[0]; // adds an array to each dimension of the array
        // each of these arrays in our data array has 0 elements in it
        // we essentially have data[col][row], each ready to be filled with more chars
    }
}

int Tetris::get_width(){
    return width;
}

void Tetris::add_piece(char shape, int rotation, int position)
{
    int *h = heights;
    int block_height = get_max_height();
    char** board = new char*[width];
    if(shape == 'I')
    {
        if(rotation==0 || rotation==180) // both orientations structurally the same
        {
            for(int i = 0; i < 4; ++i){
                board[position][block_height+i] = 'L';
            }
            
        }
    }
    
}

int Tetris::get_max_height() const{
    int hold = 0;
    for(int i=0; i<width; ++i){
        if (heights[i] > hold)
            hold = heights[i];
    }
    return hold;
}

int count_squares(){
    return 0;
}